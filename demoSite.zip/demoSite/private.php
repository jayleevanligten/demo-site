<?php
$paginaTitel = 'Private';
$paginaType = 'prive';
require('php/header.php');
?>

<h1>Dit is een private pagina.</h1>

<?php
require('php/footer.php');
?>